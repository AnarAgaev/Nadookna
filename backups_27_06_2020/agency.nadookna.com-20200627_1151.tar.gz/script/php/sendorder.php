<?php
	
	/********************** 
	
		СКРИПТ ОТПРАВКИ СООБЩЕНИЯ ИЗ ВСПЛЫВАЮЩЕЙ ФОРМЫ --ХОЧУ ПРОЕКТ--
	
	***********************/
	
	$email = 'anar.n.agaev@gmail.com';
	
	$json_works = array();
	$json_works = json_decode($_POST['works']);
	
	$res_works = array(
		"develop" => "---",
		"adver" => "---",
		"seo" => "---",
		"corporat" => "---",
		"support" => "---",
		"adaptive" => "---",
	);

	foreach($res_works as $key => $val){
		if(array_search($key, $json_works) !== false) $res_works[$key] = 'нужно';
	}

	if (isset($_POST['name']) and isset($_POST['mail']) and isset($_POST['phone']) and isset($_POST['feedcontent']) and isset($_POST['other'])){
		
		//удаляем лишние пробелы, создаём переменные с данными
		$name = trim($_POST['name']);
		$mail = trim($_POST['mail']);
		$phone = trim($_POST['phone']);
		$feedcontent = trim($_POST['feedcontent']);
		$other = trim($_POST['other']);

		// вырезаем теги
		$name = strip_tags($name); 
		$mail = strip_tags($mail); 
		$phone = strip_tags($phone); 
		$feedcontent = strip_tags($feedcontent); 
		$other = strip_tags($other); 
	
		//конвертируем специальные символы
		$name = htmlspecialchars($name,ENT_QUOTES);
		$mail = htmlspecialchars($mail,ENT_QUOTES);
		$phone = htmlspecialchars($phone,ENT_QUOTES);
		$feedcontent = htmlspecialchars($feedcontent,ENT_QUOTES);
		$other = htmlspecialchars($other,ENT_QUOTES);
		
		// Если директива magic_quotes_gpc включена, то удаляем защитные косые черты во всех переменных
		if (get_magic_quotes_gpc()) {
			$name = stripcslashes($name);
			$mail = stripcslashes($mail);
			$phone = stripcslashes($phone);
			$feedcontent = stripcslashes($feedcontent);
			$other = stripcslashes($other);
		}
		
		// Посылаем письмо на указанный мэйл:
		// создаем сообщение
		$message = "Здравструйте! Новое сообщение с веб сайта AGAEV.AGENCY\r\n";
		$message .= "Сообщение отправлено из всплывающей формы -- ХОЧУ ПРОЕКТ --\r\n\n";
		$message .= "-------------------------------------------------------------\r\n\n";
		$message .= "Данные посетителя сайта:\r\n";
		$message .= "Имя: ".$name."\r\n";
		$message .= "Мэйл: ".$mail."\r\n";
		$message .= "Телефон: ".$phone."\r\n\n";
		
		$message .= "Отправителя интересует услуга:\r\n";
		$message .= "Разработка: ".$res_works['develop']."\r\n";
		$message .= "Продвижение: ".$res_works['seo']."\r\n";
		$message .= "Поддержка: ".$res_works['support']."\r\n";
		$message .= "Реклама в интернете: ".$res_works['adver']."\r\n";
		$message .= "Корпоративный портал: ".$res_works['corporat']."\r\n";
		$message .= "Адаптивная версия сайта: ".$res_works['adaptive']."\r\n";
		if ($other == '') $other = '---';
		$message .= "Другое: ".$other."\r\n\n";
		if ($feedcontent == '') $feedcontent = '---';
		$message .= "Сообщение: ".$feedcontent."\r\n\n";
		$message .= "-------------------------------------------------------------\r\n\n\n";
		$message .= "Пожалуйста свяжитесь с посетителем сайта в ближайшее время по указанным в письме контактным данным.\r\n\n\n";
		
		$subject = "Сообщение от посетителя сайта AGAEV.AGENCY"; //тема сообщения
		$subject = "=?utf-8?b?". base64_encode($subject) ."?=";

		// Создаем заголовок header. Он одинаковый для всех сообщений с сайта
		$from = "AGAEV.AGENCY";
		$from = "=?utf-8?b?". base64_encode($from) ."?=";	
		$header = "Content-type: text/plain; charset=utf-8\r\n";
		$header .= "From: ".$from."<hi@agaev.agency>\r\n";
		$header .= "MIME-Version: 1.0\r\n"; 
		$header .= "Date: ".date('D, d M Y h:i:s O'); 
		
		if(mail($email, $subject, $message, $header)) echo 'true'; //отправляем сообщение
		else echo 'false';
	}
	else echo 'false';
?>