<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="robots" content="index, follow">
    <meta name="author" content="Anar.N.Agaev - anar.n.agaev@gmail.com">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/template_styles.css" />
	<link rel="stylesheet" type="text/css" href="style/styles.css" />
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
	
	
	<!--[if lt IE 9]>
	 <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
</head>
<body>

	<?include_once("template/header.php");?>
	
	
	<h1>Блог</h1>
	
	<article class="list">
		<h4><a href="">Шаблоны соглашений на обработку персональных данных для ваших сайтов</a></h4>
		<p>Упрощаем рутину в связи с новостями о штрафах за нарушение закона о персональных данных</p>
	</article>

	<article class="list">
		<h4><a href="">Мандэй Дайджест. Выпуск 1</a></h4>
		<p>
			Традиционный выпуск понедельничного дайджеста. Полезные сервисы и продукты, свежие 
			релизы, советы для «почитать» и вдохновляющие анимации.
		</p>
	</article>
	
	<article class="list">
		<h4><a href="">Кейс. Как мы баскетбольному клубу билетную систему делали.</a></h4>
		<p>
			Один из самых интересных кейсов. Рассказ о разработке билетной системы для 
			баскетбольного клуба «Буревестник».
		</p>
	</article>
	
	<article class="list">
		<h4><a href="">Мандэй Дайджест. Start</a></h4>
		<p>
			Дизайн для государства, обновление Sketch и Photoshop, шуточки про чехлы, итоги 2015 
			года, полезный подкаст и приятный бонус для дизайнеров. 
		</p>
	</article>

	<?include_once("template/footer.php");?>

</body>
</html>