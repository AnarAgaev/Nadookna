	<div class="overlay">
		<a href="#" class="closeFeedbackc">Закрыть</a>
		<div class="feedback clearfix">
            <div class="feedbackLeftBlock">
                <h2>Хочу проект</h2>
				<p>Заполните простую форму заявки на проект или свяжитесь с нами по телефону или почте.</p>
				<span>+7 (980) 701-17-18</span>
				<a href="mailto:hi@agaev.agency">hi@agaev.agency</a>
            </div>
            <div class="feedbackRightBlock">
				<form action="" method="post" enctype="multipart/form-data" id="order">
					<label for="name">Ваше имя</label><input type="text" id="name">
					<label for="mail">Электронная почта</label><input type="text" id="mail">
					<label for="phone">Телефон</label><input type="text" id="phone">
					<label for="other">Какая услуга вас интересует?</label>
                    <div class="feedbackOrders clearfix">
                        <label><input name="work" value="develop" type="checkbox"> Разработка</label>
                        <label><input name="work" value="adver" type="checkbox"> Реклама в интернете</label>
                        <label><input name="work" value="seo" type="checkbox"> Продвижение</label>
                        <label><input name="work" value="corporat" type="checkbox"> Корпоративный портал</label>
                        <label><input name="work" value="support" type="checkbox"> Поддержка</label>
                        <label><input name="work" value="adaptive" type="checkbox"> Адаптивная версия сайта</label>
                    </div>
					
					<label for="other">Другое</label><input type="text" id="other">
					<label for="feedcontent">Комментарий</label><textarea id="feedcontent"></textarea>
					<div class="buttonSmoll btnRoundBorder btnFeedback" id="orderSubmit">отправить</div>
					<span>
						Нажимая кнопку «Отправить», Вы даёте согласие<br>на
						<a href="/obrabotka-personalnyh-dannyh.php" target="_blank">обработку персональных данных</a>.
					</span>
				</form>	
            </div>
            <div class="clear"></div>
        </div>
	</div>

	<?include_once 'script/php/geturl.php';?>
	<?if(substr_count($result, 'portfolio')>0):?>
		<div id="goToTop" alt="Наверх" titel="Наверх"><span></span><div></div><span></span></div>
	<?endif;?>
	
	
	<header>
		<span id="backHead"></span>
		<div class="templateWrap">
			<a class="logo" href="/">
				<svg version="1.1" width="40" height="40" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 50 48.9" xml:space="preserve">
				<style type="text/css">
					.st0{fill-rule:evenodd;clip-rule:evenodd;}
				</style>
				<path class="st0" d="M24.4,35.7c-0.4,0.4-0.7,0.7-1.1,1.1c-1.5,1.3-3.2,2.3-5.7,2.4c-3.7-0.6-5.3-2.6-5.4-5.5
					c-0.4-4.2,1.8-7.7,5.2-10.5c2.4,0.5,5,1,7.4,1.5C24.7,29.5,24.5,34.2,24.4,35.7L24.4,35.7z M19.3,18.1c1.8-0.7,3.7-1.5,5.6-2.3
					c0-2.7-0.1-4.8-0.3-5.5c-2.1-6.8-11.3-3.7-9.9,2.5C15.1,14.8,17,16.6,19.3,18.1L19.3,18.1z M24.9,19c-0.3,0.1-0.8,0.4-1.9,1
					c0.6,0.2,1.1,0.4,1.7,0.6c0.1,0,0.1,0,0.2,0.1C24.9,20.1,24.9,19.5,24.9,19L24.9,19z M35.1,14.5c2.4-1.4,5.3-2.3,7.2-2.3
					c0.8-0.3,0.2,0.6,0.2,1.5c0,1.8,1.5,3.2,3.2,3.2c1.8,0,3.2-1.5,3.2-3.2c0-5.6-7.4-3.5-13.8-1.4l0.1-4.1C34.1,2.6,28.5,0.1,20.6,0
					C5.3,0.8-0.5,16,9.7,20.8c0.5,0.2,1,0.4,1.6,0.7C5.2,24.6,0.3,28.9,0,36.1c-0.4,11.2,13.1,18.5,24.7,6.5c3.7,10.8,25.4,6.8,25.2-4.8
					c-0.1-7.4-7.6-11.6-15.1-14.3l-0.2,11c0.1,2.5,1.6,7.7,5,6.9c2.1-0.5,3.2-2.2,3.2-5.3c-0.8-5.2-3.5-8.2-8.1-9.3c0-1.3,0-1.8,0.1-3.3
					L35.1,14.5z M35.1,14.5"/>
				</svg>
			</a>
			<nav>
				<ul>
					<li><a <?php if(substr_count($result, 'portfolio')>0) echo'class="activeNavPoint"';?> href="/portfolio.php">ПОРТФОЛИО<span></span></a></li>
					<li><a <?php if(substr_count($result, 'blog')>0) echo'class="activeNavPoint"';?> href="/blog.php">БЛОГ<span></span></a></li>
					<li><a <?php if(substr_count($result, 'kontakty')>0) echo'class="activeNavPoint"';?> href="/kontakty.php">КОНТАКТЫ<span></span></a></li>
				</ul>
			</nav>
			<div class="buttonSmoll btnRoundBorder btnHead">хочу проект</div>
		</div>
	</header>
	
	
	<div class="content">
	
	
		<section>
